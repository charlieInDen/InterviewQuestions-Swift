//: [Previous](@previous)

import Foundation


//Input : [2, 1, 2]
//Return  : 2 which occurs 2 times which is greater than 3/2.
class Solution {
    func majorityElement(_ A: [Int]) -> Int {
        if A.count == 0 {
            return -1
        }
        var majorityNo = A[0]
        var count = 0
        for item in A {
            if count == 0 {
                majorityNo = item
            }
            count += (item == majorityNo ? 1 : -1)
        }
        
        return majorityNo
    }
}
let input = [2, 1, 2]
let solution = Solution()
let result = solution.majorityElement(input)
print(result)

