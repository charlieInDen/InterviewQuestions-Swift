//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

//: [Next](@next)

class MaxRectangleInBinaryMatrix {
    //0, 1, 1, 0
    func findMaxHistogram(_ row: [Int]) -> Int {
        var result: [Int] = [] //Index array(stack)
        var area = 0
        var maxArea = 0
        let size = row.count
        var i = 0
        while i < size {
            if result.isEmpty || row[(result.last ?? 0)] <= row[i] {
                result.append(i)
                i += 1
            }else {
                let top = result.removeLast()
                let x = row[top]
                area = x * i
                
                if result.isEmpty == false {
                    area = x * ( i - (result.last ?? 0) - 1 )
                }
                maxArea = max(area, maxArea)
            }
            
        }
        // Now pop the remaining bars from stack and calculate area
        // with every popped bar as the smallest bar
        while !result.isEmpty {
            let top = result.removeLast()
            let x = row[top]
            area = x * i
            if result.isEmpty == false {
                area = x * ( i - (result.last ?? 0) - 1 )
            }
            maxArea = max(area, maxArea)
        }
        return maxArea;
    }
    func maximalRectangle(_ A: inout [[Int]]) -> Int {
        // Calculate area for first row and initialize it as
        // result
        var result = findMaxHistogram(A[0]);
           // iterate over row to find maximum rectangular area
        // considering each row as histogram
        for (i, row) in A.enumerated() {
            for (j, _) in row.enumerated() {
                // if A[i][j] is 1 then add A[i -1][j]
                if A[i][j] == 1 && i > 0 {
                    A[i][j] += A[i - 1][j]
                }
            }
            // Update result if area with current row (as last row)
            // of rectangle) is more
            result = max(result, findMaxHistogram(A[i]))
        }
        return result;
    }
}
var arr =  [[1, 1, 1], [0, 1, 1], [1, 0, 0]]
let solution = MaxRectangleInBinaryMatrix()
let result = solution.maximalRectangle(&arr)

