//: [Previous](@previous)

import Foundation

var str = "Hello, playground"
extension String {
    subscript(i: Int) -> String {
        return String(self[index(startIndex, offsetBy: i)])
    }
}
//: [Next](@next)
class Solution {
    func minDistance(_ A: inout String, _ B: inout String) -> Int {
        var D: [[Int]]! = []
        //Initialize dp array
        for i in 0...A.count {
            D.append([])
            for _ in 0...B.count {
                D[i].append(0)
            }
        }
//        Base conditions:
//        D(i,0) = i
//        D(0,j) = j
        for i in 0..<A.count {
            D[i][0] = i
        }
        for j in 0..<B.count {
            D[0][j] = j
        }
//        Recurrence Relation
        for i in 1...A.count {
            for j in 1...B.count {
                var replace = D[i-1][j-1]
                if A[i - 1] != B[j - 1] {
                    replace += 1
                }
                let insertion = 1 + D[i][j-1]
                let deletion = 1 + D[i-1][j]
                D[i][j] = min(min(insertion,deletion), replace)
            }
        }
        return D[A.count][B.count]
    }
}
var a = "intention"
var b = "execution"

let solution = Solution()
let result = solution.minDistance(&a, &b)
print(result)

a = "saturday"
b = "sunday"
let secondResult = solution.minDistance(&a, &b)
print(secondResult)
