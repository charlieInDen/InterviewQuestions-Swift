//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

//: [Next](@next)
//In a binary tree, if in the path from root to the node A, there is no node with greater value than A's, this node A is visible. We need to count the number of visible nodes in a binary tree.

import Foundation
// Definition for a binary tree node.
public class TreeNode {
    public var val: Int
    public var left: TreeNode?
    public var right: TreeNode?
    public init(_ val: Int) {
        self.val = val
        self.left = nil
        self.right = nil
    }
}

final class CountVisibleNode {
    func iterativeDFSTraversal(_ root: TreeNode?) -> Int {
        guard let root = root else { return 0 }
        var result: Int = 0
        var stack: [TreeNode] = []
        var visited: [Int: Bool] = [ : ]
        var maxStack: [Int] = []
        //Assumption possible numbers are greater than Int.min
        var max: Int = Int.min
        stack.append(root)
        visited[root.val] = true
        maxStack.append(root.val)

        while stack.isEmpty == false {
            guard let element = stack.last, let stackMax = maxStack.last else { break }
            if visited[element.val] == true {
                stack.removeLast()
                maxStack.removeLast()
            }
            if stackMax <= element.val {
                max = element.val
                print("visible nodes are \(max)")
                result += 1
            }
            //Traverse neighbours
            if let left = element.left, visited[left.val] == nil {
                visited[left.val] = true
                stack.append(left)
                maxStack.append(max)
            }
            if let right = element.right, visited[right.val] == nil {
                visited[right.val] = true
                stack.append(right)
                maxStack.append(max)
            }
        }
        
        return result
    }
    //Find visible nodes
    func visibleNodes(_ root: TreeNode?) -> Int {
        let result: Int = iterativeDFSTraversal(root)
        return result
    }
}

let solution = CountVisibleNode()
//[3,5,1,6,2,0,8,null,null,7,4]
//       5
//     /  \
//   3     10
//  /  \   /
//20   21 1
let rootNode: TreeNode = TreeNode(5)
rootNode.left = TreeNode(3)
rootNode.right = TreeNode(10)
rootNode.left?.left = TreeNode(20)
rootNode.left?.right = TreeNode(21)
rootNode.right?.left = TreeNode(1)
//Print
//Find result
let result = solution.visibleNodes(rootNode)
print(result )
//Input:
//  -10
//    \
//    -15
//       \
//       -1
//
//Output: 2
//Explanation: Visible nodes are -10 and -1.
let rootNode2: TreeNode = TreeNode(-10)
rootNode2.right = TreeNode(-15)
rootNode2.right?.right = TreeNode(-1)
//Print
//Find result
let result2 = solution.visibleNodes(rootNode2)
print(result2 )
