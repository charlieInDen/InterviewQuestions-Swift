/*
 https://leetcode.com/problems/all-nodes-distance-k-in-binary-tree/
 We are given a binary tree (with root node root), a target node, and an integer value K.
 Return a list of the values of all nodes that have a distance K from the target node.  The answer can be returned in any order.
 Input: root = [3,5,1,6,2,0,8,null,null,7,4], target = 5, K = 2
 Output: [7,4,1]
 Explanation:
 The nodes that are a distance 2 from the target node (with value 5)
 have values 7, 4, and 1.
 Note that the inputs "root" and "target" are actually TreeNodes.
 The descriptions of the inputs above are just serializations of these objects.
 
 Note:
 The given tree is non-empty.
 Each node in the tree has unique values 0 <= node.val <= 500.
 The target node is a node in the tree.
 0 <= K <= 1000.
 */
import Foundation
// Definition for a binary tree node.
public class TreeNode {
    public var val: Int
    public var left: TreeNode?
    public var right: TreeNode?
    public init(_ val: Int) {
        self.val = val
        self.left = nil
        self.right = nil
    }
}

final class AllNodesAtDistanceK {
    private func iterativeInorderTraversal(_ root: TreeNode?, map: inout [Int: TreeNode]) {
        guard let root = root else { return }
        //Left-Node-Right (LNR) traversal
        var currentNode: TreeNode? = root
        var stack: [TreeNode] = []
        map[root.val] = nil
        
        while currentNode != nil {
            if let left = currentNode?.left {
                stack.append(left)
                map[left.val] = currentNode
            }
            if let right = currentNode?.right {
                stack.append(right)
                map[right.val] = currentNode
            }
            if stack.isEmpty {
                currentNode = nil
            } else {
                currentNode = stack.removeLast()
            }
        }
    }
    // Store parent information
    private func storeParentInformation(_ root: TreeNode?) -> [Int: TreeNode] {
        var map: [Int: TreeNode] = [ : ]
        iterativeInorderTraversal(root, map: &map)
        return map
    }
    //Traverse from target node at k distance
    private func bfs(_ target: TreeNode?, _ K: Int, _ map: [Int: TreeNode]) -> [Int] {
        guard let target = target else { return [] }
        var result: [Int] = []
        var queue: [TreeNode] = []
        var currentNode: TreeNode? = target
        var level: Int = 0
        var visited: [Int: Bool] = [ : ]
        queue.append(target)
        visited[target.val] = true
        while queue.isEmpty == false {
            //Break case - check if level is equal to K
            if level == K {
                while !queue.isEmpty {
                    result.append(queue.removeFirst().val)
                }
                break
            }
            //Based on each level - insert the element (Level Order Traversal)
            var size = queue.count
            while size > 0 {
                currentNode = queue.removeFirst()
                if let left = currentNode?.left, visited[left.val] == nil {
                    queue.append(left)
                    visited[left.val] = true
                }
                if let right = currentNode?.right, visited[right.val] == nil {
                    queue.append(right)
                    visited[right.val] = true
                }
                if let node = currentNode, let parent = map[node.val], visited[parent.val] == nil {
                    queue.append(parent)
                    visited[parent.val] = true
                }
                size -= 1
            }
            
            level += 1
            
        }
        
        return result
    }
    //Find all nodes at K distance from given target node
    func distanceK(_ root: TreeNode?, _ target: TreeNode?, _ K: Int) -> [Int] {
        //Store parent information so that BFS can easily work from target node
        let map: [Int: TreeNode] = storeParentInformation(root)
        let result: [Int] = bfs(target, K, map)
        return result
    }
}
//Left-Node-Right (LNR) traversal
func printInorder(_ root: TreeNode?) {
    if let root = root {
        printInorder(root.left)
        print(root.val)
        printInorder(root.right)
    }
}

let solution = AllNodesAtDistanceK()
//[3,5,1,6,2,0,8,null,null,7,4]
let K: Int = 2
let rootNode: TreeNode = TreeNode(3)
let targetNode = TreeNode(5)
rootNode.left = targetNode

rootNode.right = TreeNode(1)
rootNode.left?.left = TreeNode(6)
rootNode.left?.right = TreeNode(2)
rootNode.left?.right?.left = TreeNode(7)
rootNode.left?.right?.right = TreeNode(4)
rootNode.right?.left = TreeNode(0)
rootNode.right?.right = TreeNode(8)
//Print
printInorder(rootNode)
//Find result
let result = solution.distanceK(rootNode, targetNode, K)
print(result )
